<?php
$conn = new mysqli("localhost", "root", "", "db_registration");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $event_name = $_POST['event_name'];
    $event_date = $_POST['event_date'];
    $event_time = $_POST['event_time'];
    $location = $_POST['location'];
    $description = $_POST['description'];

    $upload_dir = "uploads/";
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    $approval_letter_path = "";
    if (isset($_FILES['approval_letter']) && $_FILES['approval_letter']['error'] === UPLOAD_ERR_OK) {
        $filename = basename($_FILES["approval_letter"]["name"]);
        $approval_letter_path = $upload_dir . $filename;
        move_uploaded_file($_FILES["approval_letter"]["tmp_name"], $approval_letter_path);
    }

    $sql = "INSERT INTO events (event_name, event_date, event_time, location, description, approval_letter, status)
            VALUES ('$event_name', '$event_date', '$event_time', '$location', '$description', '$approval_letter_path', 'Upcoming')";

    if ($conn->query($sql) === TRUE) {
        echo "New event created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
}
?>
