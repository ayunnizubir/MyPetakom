<?php
$conn = new mysqli("localhost", "root", "", "db_registration");
$result = $conn->query("SELECT * FROM events");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Event List</title>
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.1/build/qrcode.min.js"></script>
    <style>
        .qr-img {
            max-width: 100px;
        }
        canvas {
            border: 1px solid #ccc;
            border-radius: 6px;
            background: white;
        }
        td {
            vertical-align: middle;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <img src="../petakom_logo.png" alt="PETAKOM Logo">
        <h2>MyPetakom</h2>
        <ul>
            <li><a href="../Advisor/dashboard_advisor.php">Dashboard Event Advisor</a></li>
            <li><a href="../Advisor/create_event.html">Create Event</a></li>
            <li><a href="event_list.php">Event List</a></li>
            <li><a href="../Advisor/committee.php">Committee</a></li>
            <li><a href="../Advisor/merit_applications.php">Merit Application</a></li>
        </ul>
    </div>

    <div class="main">
        <div class="header">
            <h1>Event List</h1>
            <div class="profile">
                <div class="profile-icon">👤</div>
                <span>User's Name</span>
                <button>Sign Out</button>
            </div>
        </div>

        <div class="container">
            <h2>All Events</h2>
            <table>
                <tr>
                    <th>No</th>
                    <th>Event Name</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Location</th>
                    <th>Status</th>
                    <th>QR Code</th>
                </tr>
                <?php $i = 1; while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $i++ ?></td>
                    <td><?= $row['event_name'] ?></td>
                    <td><?= $row['event_date'] ?></td>
                    <td><?= $row['event_time'] ?></td>
                    <td><?= $row['location'] ?></td>
                    <td><?= $row['status'] ?></td>
                    <td>
                        <?php if ($row['status'] == 'Approved'): ?>
                        <div style="display: flex; flex-direction: column; align-items: center; gap: 5px;">
                            <canvas id="qr-<?= $row['id'] ?>" style="margin: 0 auto;"></canvas>
                            <a href="../Event/view_event.php?event_id=<?= $row['id'] ?>" target="_blank">
                                <button class="qr" style="padding: 4px 10px; font-size: 12px;">View</button>
                            </a>
                        </div>
                        <script>
                            document.addEventListener("DOMContentLoaded", function () {
                                QRCode.toCanvas(document.getElementById("qr-<?= $row['id'] ?>"),
                                    "http://10.65.90.56/mypetakom/Event_Registration/Event/view_event.php?event_id=<?= $row['id'] ?>",
                                    { width: 100 },
                                    function (error) {
                                        if (error) console.error(error);
                                    });
                            });
                        </script>
                        <?php else: ?>
                            <em>Pending</em>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            </table>
        </div>
    </div>
</body>
</html>
